package com.capgemini.fileutil;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.capgemini.fileutil.exception.FileUtilException;
import com.capgemini.fileutil.service.FileUtilService;
import com.capgemini.fileutil.service.FileUtilServiceImpl;

/**
 * Unit test for Conversion of input to xml and csv
 */
public class AppTest {
	
	@Test
	public void testService() {

		FileUtilService testobj = new FileUtilServiceImpl();
		try {
			testobj.processInputFiles_to_CSV_XML("C:\\Testing\\small.in",
						"C:\\Testing");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(expected = FileUtilException.class) 
	public void testErrorInput() throws Exception{
		
		FileUtilService testobj = new FileUtilServiceImpl();
			testobj.processInputFiles_to_CSV_XML("",
						"C:\\Testing");
	}
	
	@Test(expected = FileUtilException.class) 
	public void testErrorOutput() throws Exception{
		
		FileUtilService testobj = new FileUtilServiceImpl();
		testobj.processInputFiles_to_CSV_XML("C:\\Testing\\small.in",
					"");
	}
	
	@Test
	public void testError1() {
		FileUtilService testobj = new FileUtilServiceImpl();
		try {
			testobj.processInputFiles_to_CSV_XML("",	"");
		} catch (Exception e) {
			assertEquals(e.getMessage(), "Input File Path is empty");
		}
	}
	
	@Test
	public void testError2() {
		FileUtilService testobj = new FileUtilServiceImpl();
		try {
			testobj.processInputFiles_to_CSV_XML("",	"");
		} catch (Exception e) {
			assertNotEquals(e.getMessage(), "Input File Path is empty");
		}
	}
}
