package com.capgemini.fileutil.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;

import org.xml.sax.SAXException;

import com.capgemini.fileutil.domain.Sentence;
import com.capgemini.fileutil.domain.Text;
import com.capgemini.fileutil.exception.FileUtilException;
import com.opencsv.CSVWriter;

/** Written by Prasenjit Das 
 *         FileUtilService provides logic to read input file and produce
 *         output in XML and CSV format
 *
 */
public class FileUtilServiceImpl implements FileUtilService {

    BufferedReader in;
    StreamResult out;
    TransformerHandler th;

	static final String REGEX_SEPARATOR = "(?<!(?:Jr.|Mr.))(?<=[.!?])\\s*";
	static final String XML_FILE_NAME = "small.xml";
	static final String CSV_FILE_NAME = "small.csv";

	/* 
	 * Method will convert lines into sentences
	 */
	private List<String> readSentence(String fileInputPath) throws Exception {

		String carryForward = "";

		String[] sentences;

		List<String> lstSentence = new ArrayList<>();

		List<String> lines = Files.readAllLines(Paths.get(fileInputPath));

		for (String line : lines) {
			if (!line.trim().isEmpty()) {
				if (!carryForward.trim().isEmpty()) {
					line = carryForward + line;
					carryForward = "";
				}
				sentences = line.split(REGEX_SEPARATOR);

				for (String sentence : sentences) {
					if (!(sentence.endsWith(".") || sentence.endsWith("!") || sentence.endsWith("?"))) {
						carryForward = sentence;
					} else {
						lstSentence.add(sentence);
					}
				}
			}

		}

		return lstSentence;
	}

	/*
	 * Method will create Sentence domain object which will contain list of words
	 */
	private List<Sentence> createSentences(String fileInputPath) throws Exception {

		List<Sentence> lstSentences = new ArrayList<>();
		Sentence sentence = null;

		List<String> lstSentence = readSentence(fileInputPath);

		int num = 1;

		for (String line : lstSentence) {
			sentence = new Sentence();
			sentence.setName("Sentence " + num);
			for (String word : line.split(" ")) {
				if (!word.trim().isEmpty())
					sentence.addWord(word.trim());
			}
			lstSentences.add(sentence);
			num++;
		}

		return lstSentences;
	}

	
	 public void process(String s) throws SAXException {
	   
	        System.out.println("Character array in process"+s);
	        
	        th.startElement(null, null, "word", null);
	        th.characters(s.toCharArray(),0, s.length());    
	        th.endElement(null, null, "word");
	    }

	    public void closeXml() throws SAXException {
	        th.endElement(null, null, "text");
	        th.endDocument();
	    }
	    
	    public void openXml() throws ParserConfigurationException, TransformerConfigurationException, SAXException {

	        SAXTransformerFactory tf = (SAXTransformerFactory) SAXTransformerFactory.newInstance();
	        th = tf.newTransformerHandler();

	        // pretty XML output
	        Transformer serializer = th.getTransformer();
	        serializer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
	        serializer.setOutputProperty(OutputKeys.STANDALONE,"yes");
	        serializer.setOutputProperty(OutputKeys.INDENT, "yes");
	        th.setResult(out);
	        th.startDocument();
	        th.startElement(null, null, "text", null);
	    }
	    
	    /* Method converts given input file content into XML file
		 * file
		 */
	@Override
	public void xmlFileConversion(String fileInputPath, String fileOutputPath) throws Exception {
		try {
               System.out.println("fileInputPath IS>>"+fileInputPath);
               System.out.println("fileOutputPath IS>>"+fileOutputPath);
	
		in = new BufferedReader(new FileReader(fileInputPath));
        out = new StreamResult(fileOutputPath+ "\\" + XML_FILE_NAME);
        openXml();//writing header tags
        String str;       
        String[] arr ;   
         while ((str = in.readLine()) != null) {
        	 System.out.println("Line is"+str);            	 
        	arr = str.split("\\W+"); 
        	
        	 th.startElement(null, null, "sentence", null); 
        	for ( String ss : arr) {
        	    process(ss);            	    
        	}
        	 th.endElement(null, null, "sentence");
      	}
         in.close();
         closeXml();
	}
         catch (Exception e) {
             e.printStackTrace();
         }
	}

	/* Method converts given input file content into CSV file
	 * file
	 */
	@Override
	public void csvFileConversion(String fileInputPath, String fileOutputPath) throws Exception {

		
		 System.out.println("fileInputPath IS>>"+fileInputPath);
         System.out.println("fileOutputPath IS>>"+fileOutputPath);
         
		File file = new File(fileOutputPath + "\\" + CSV_FILE_NAME);

		// Create FileWriter object with file path as parameter
		FileWriter outputfile = new FileWriter(file);

		// Create CSVWriter object filewriter object as parameter
		CSVWriter writer = new CSVWriter(outputfile);

		// create a List which contains String array
		List<String[]> csvData = new ArrayList<String[]>();
		csvData.add(createCSVHeader());

		List<Sentence> lstSentences = createSentences(fileInputPath);

		lstSentences.forEach(sentence -> {
			String[] data = { sentence.getName() };

			String[] arr = sentence.getWords().stream().toArray(String[]::new);

			csvData.add(Stream.concat(Arrays.stream(data), Arrays.stream(arr)).toArray(String[]::new));
		});

		writer.writeAll(csvData);

		// closing writer connection
		writer.close();
	}

	// Cerating CSV Header
	private String[] createCSVHeader() {

		String[] header = new String[40];

		header[0] = "";

		IntStream stream = IntStream.range(1, 40);
		stream.forEach(i -> {
			header[i] = "Word " + i;
		});

		return header;
	}

	/** 
	 * Method processes given input file and converts it into XML and CSV files
	 */
	@Override
	public void processInputFiles_to_CSV_XML(String fileInputPath, String fileOutputPath) throws Exception {

		if (fileInputPath.trim().isEmpty()) {
			throw new FileUtilException("Input File Path is empty");
		}
		if (fileOutputPath.trim().isEmpty()) {
			throw new FileUtilException("Output File Path is empty");
		}
/*For Conversion of xml file function defined*/
		xmlFileConversion(fileInputPath, fileOutputPath);
/*For Conversion of csv file function defined*/
		csvFileConversion(fileInputPath, fileOutputPath);
	}
}
