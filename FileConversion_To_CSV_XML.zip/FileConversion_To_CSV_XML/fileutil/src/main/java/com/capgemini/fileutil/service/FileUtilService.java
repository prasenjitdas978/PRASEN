package com.capgemini.fileutil.service;

public interface FileUtilService {

	void xmlFileConversion(String fileInputPath, String fileOutputPath) throws Exception;

	void csvFileConversion(String fileInputPath, String fileOutputPath) throws Exception;

	void processInputFiles_to_CSV_XML(String fileInputPath, String fileOutputPath) throws Exception;
}
