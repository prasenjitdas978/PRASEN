package com.capgemini.fileutil.domain;

import java.util.ArrayList;
import java.util.List;


public class Sentence {

	String name;
	
	List<String> words = new ArrayList<>();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public List<String> getWords() {
		return words;
	}

	public void setWords(List<String> words) {
		this.words = words;
	}

	public void addWord(String word) {
		this.words.add(word);
	}

	
}
