package com.capgemini.fileutil.domain;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Text {

	private List<Sentence> sentence;

	@XmlElement
	public List<Sentence> getSentences() {
		return sentence;
	}

	public void setSentences(List<Sentence> sentence) {
		this.sentence = sentence;
	}
}
