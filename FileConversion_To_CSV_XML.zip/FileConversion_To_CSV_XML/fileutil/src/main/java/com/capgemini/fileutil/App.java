package com.capgemini.fileutil;

import com.capgemini.fileutil.service.FileUtilService;
import com.capgemini.fileutil.service.FileUtilServiceImpl;

/*Written By Prasenjit Das*/
public class App {
	public static void main(String[] args) {
		try {
/*Input file from Argument to be passed*/
/*OutputFilepath from Argument to be passed*/
			String strInputFile = args[0];
			String strOutputPath = args[1];
			FileUtilService obj = new FileUtilServiceImpl();

		
			obj.processInputFiles_to_CSV_XML(strInputFile, strOutputPath);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
