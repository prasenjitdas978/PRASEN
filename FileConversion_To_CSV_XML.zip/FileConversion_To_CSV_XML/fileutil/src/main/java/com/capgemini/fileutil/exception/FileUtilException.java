package com.capgemini.fileutil.exception;

public class FileUtilException extends Exception{

	public FileUtilException() {
		super();
	}
	
	public FileUtilException(String error) {
		super(error);
	}
}
