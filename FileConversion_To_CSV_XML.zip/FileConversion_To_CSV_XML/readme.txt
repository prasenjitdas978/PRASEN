The program needs two arguments while running as java application

Run the below command:

java App "inputfilepath" "ouputfilepath"

java App C:\\Testing\\small.in C:\\Testing(RUNNING FROM COMMAND LINE)

C:\\Testing\\small.in C:\\Testing(If running from eclipse command line please pass these arguments with the input file small.in placed in the system location)

* enter inputfilepath place the folder in the path with the input text file :  "C:\\Testing\\small.in"

* For outputfilepath enter mention the folder name where we want to save output file in "C:\\Testing" then enter the path only
  
* Output File names : small.csv and small.xml will be created in the location  provided as the outputfilepath in above.
